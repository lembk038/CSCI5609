# 5609 Visualization-Assignments

Instructions and supporting materials for the CSCI 5609 Visualization Class.

For demos, visit: https://qianwen.info/my-vis-5609/
